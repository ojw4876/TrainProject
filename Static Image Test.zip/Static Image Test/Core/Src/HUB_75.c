/*
 * HUB_75.c
 *
 *  Created on: 20 lut 2021
 *      Author: Teodor
 */

#include "HUB_75.h"
#include "main.h"
#include "stm32h7xx_it.h"
#include "stdbool.h"

//@here define the brightness
//min 1 max 100;
#define scr_brightness 90

void Send_BUF_IN_SCR(uint8_t *SendBuffer);
void Select_Send_Buf(uint8_t *BITMAP);
void PrepareRowPart(uint8_t *BMP,uint8_t *OUT_B);

extern TIM_HandleTypeDef htim4;
extern DMA_HandleTypeDef hdma_dma_generator0;

//extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim5;
extern TIM_HandleTypeDef htim2;
//Global helper variables
int LINE=0;
//Initialize OSPI_Command structure
//Zabawa z typedefem - estetyka
SCR_State_Proces_TypeDef My_Scr_Status;
SCR_PROCES SCR_PROCESS;
uint8_t *SendingBuffer_Adr=0;
uint8_t arr[64];

const uint8_t* err = "Error\r\n";
const uint8_t* ok = "Pass\r\n";
const uint8_t* busy = "Busy\r\n";

extern UART_HandleTypeDef huart3;

void TIM5_CallBack()
{
	HAL_GPIO_WritePin(LATCH_GPIO_Port, LATCH_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(LATCH_GPIO_Port, LATCH_Pin, GPIO_PIN_RESET);
	Send_BUF_IN_SCR( SendingBuffer_Adr );

}

void Send_BUF_IN_SCR(uint8_t *SendBuffer)
{
	HAL_StatusTypeDef status;
	if (HAL_DMA_GetState(&hdma_dma_generator0) == HAL_DMA_STATE_READY) {
		if(LINE>15)
		{
		  LINE=-1;
		}
		LINE++;
		status = HAL_DMA_Start_IT(&hdma_dma_generator0, (uint32_t) SendingBuffer_Adr /*+ (LINE * 64)*/, (uint32_t) &GPIOF->ODR, 64);
		HAL_GPIO_WritePin(LINE_A_GPIO_Port, LINE_A_Pin, (LINE & (1 << 0)) ? GPIO_PIN_SET : GPIO_PIN_RESET); // A
		HAL_GPIO_WritePin(LINE_B_GPIO_Port, LINE_B_Pin, (LINE & (1 << 1)) ? GPIO_PIN_SET : GPIO_PIN_RESET); // B
		HAL_GPIO_WritePin(LINE_C_GPIO_Port, LINE_C_Pin, (LINE & (1 << 2)) ? GPIO_PIN_SET : GPIO_PIN_RESET); // C
		HAL_GPIO_WritePin(LINE_D_GPIO_Port, LINE_D_Pin, (LINE & (1 << 3)) ? GPIO_PIN_SET : GPIO_PIN_RESET); // D

		if (status == HAL_OK) {
			HAL_UART_Transmit(&huart3, ok, sizeof(ok), 100000);
		}
		else if (status == HAL_ERROR){
			HAL_UART_Transmit(&huart3, err, sizeof(err), 100000);
		}
		else if (status == HAL_BUSY) {
			HAL_UART_Transmit(&huart3, busy, sizeof(busy), 100000);
		}
	}
}


void HAL_DMA_TxCpltCallback(DMA_HandleTypeDef *hdma)
{
	HAL_Delay(1);
	HAL_GPIO_TogglePin(LATCH_GPIO_Port, LATCH_Pin);
	HAL_Delay(1);
	HAL_GPIO_TogglePin(LATCH_GPIO_Port, LATCH_Pin);

	__HAL_TIM_SET_COMPARE(&htim4,TIM_CHANNEL_1,100-scr_brightness);

}

void HUB_75_INIT()
{
	hdma_dma_generator0.XferCpltCallback = HAL_DMA_TxCpltCallback;
	SendingBuffer_Adr = arr;
	for (int i = 0; i < 64; i++)
	{
		arr[i] = 0x3F;
	}

	HAL_TIM_Base_Start_IT(&htim5);

	HAL_GPIO_WritePin(LINE_A_GPIO_Port, LINE_A_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(LINE_B_GPIO_Port, LINE_B_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(LINE_C_GPIO_Port, LINE_C_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(LINE_D_GPIO_Port, LINE_D_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(LATCH_GPIO_Port,LATCH_Pin,GPIO_PIN_RESET);

	HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_1);
	__HAL_TIM_SET_COMPARE(&htim4,TIM_CHANNEL_1,0);
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
}





